# DSPy Knowledge Base — Offline Usage Guide

> 🚀 **Zero-internet DSPy reference for air-gapped environments.**
>
> This package contains everything an AI coding agent needs to write correct DSPy 3.x code — no pip install, no git clone, no API calls required.

---

## 📦 What's Inside

| Component | Count | Description |
|---|---|---|
| **Patterns** | 22 | Design patterns with MVP code, anti-patterns, composition guides |
| **Core Docs** | 4 | Core concepts, API cheatsheet, migration guide, common pitfalls |
| **IDE Configs** | 3 | Cursor rules, Claude context, system prompt |
| **Tools** | 2 | Offline search + validation scripts |

**Total:** ~3,700 lines of documentation, all plain text Markdown.

---

## ⚡ Quick Start (30 seconds)

### 1. Find the right pattern

```bash
# List all patterns
python scripts/search.py --list

# Search for RAG-related patterns
python scripts/search.py "RAG"

# Find advanced patterns only
python scripts/search.py --difficulty advanced
```

### 2. Read the pattern

Open the Markdown file in any text editor:

```bash
# macOS
open patterns/rag.md

# Linux
gedit patterns/rag.md

# VS Code
code patterns/rag.md
```

Each pattern has 6 sections:
1. **Core Concept** — Why this pattern exists
2. **Architecture** — ASCII data flow diagram
3. **MVP Code** — Copy-paste runnable example (DSPy 3.x)
4. **Anti-patterns** — 3+ mistakes agents make + fixes
5. **Composition** — How to combine with other patterns
6. **Advanced Variants** — Production extensions

### 3. Configure your IDE (optional)

**For Cursor:**
```bash
cp exports/.cursorrules-dspy /path/to/your/project/.cursorrules
```

**For Claude Code:**
```bash
cp exports/CLAUDE.md-dspy /path/to/your/project/CLAUDE.md
```

**For generic LLM:**
```bash
cat exports/system-prompt-dspy.md
# Paste the output into your agent's system prompt
```

---

## 🔍 Search Methods

### A. Built-in search script (recommended)

```bash
python scripts/search.py "keyword"
```

Options:
- `keyword` — Search in titles, summaries, and keywords
- `--difficulty {foundation,beginner,intermediate,advanced,expert}` — Filter by level
- `--list` — Show all patterns as a table
- `--file` — Output file paths only (for scripting)

### B. VS Code / Cursor global search

1. Open `dspy-knowledge-offline/` as a workspace
2. `Ctrl+Shift+F` (or `Cmd+Shift+F` on macOS)
3. Type any term — instant full-text search across all 22 patterns

### C. grep / ripgrep

```bash
# Find all mentions of "BootstrapFewShot"
grep -r "BootstrapFewShot" patterns/

# Find anti-patterns in advanced patterns
grep -l "difficulty: advanced" patterns/*.md | xargs grep -A5 "Anti-patterns"
```

### D. Read the catalog

`patterns/pattern-catalog.md` contains:
- **Decision Tree** — "Which pattern do I need?" flowchart
- **Composition Matrix** — "What pairs with what?" reference table
- **Batch overview** — All 22 patterns at a glance

---

## 📝 Pattern Reference by Task

| Task | Start Here |
|---|---|
| Simple classification/extraction | `patterns/predict.md` (P01) |
| Math/logic reasoning | `patterns/chain-of-thought.md` (P02) |
| Agent with tools | `patterns/react-agent.md` (P03) |
| Document Q&A | `patterns/rag.md` (P04) |
| Multi-step research | `patterns/multi-hop.md` (P05) |
| Exact computation | `patterns/program-of-thought.md` (P06) |
| Multi-stage pipeline | `patterns/custom-module.md` (P07) |
| Quality-critical output | `patterns/best-of-n.md` (P08) |
| Iterative improvement | `patterns/refine.md` (P09) |
| Concurrent analysis | `patterns/parallel.md` (P10) |
| Consensus/voting | `patterns/multi-chain-comparison.md` (P11) |
| Domain routing | `patterns/router.md` (P12) |
| Chatbot with memory | `patterns/conversation-history.md` (P13) |
| Auto few-shot selection | `patterns/bootstrap-few-shot.md` (P14) |
| Bayesian prompt optimization | `patterns/mipro-v2.md` (P15) |
| Reflective prompt evolution | `patterns/gepa.md` (P16) |
| RL agent training | `patterns/rl-optimization.md` (P17) |
| Multi-program ensemble | `patterns/ensemble.md` (P18) |
| MCP tool integration | `patterns/mcp-integration.md` (P19) |
| Real-time streaming UI | `patterns/streaming.md` (P20) |
| High-concurrency server | `patterns/async.md` (P21) |
| Deploy to production | `patterns/saving-loading.md` (P22) |

---

## 💾 Validation

Verify package integrity:

```bash
python scripts/validate.py
```

This checks:
- All 22 pattern files exist and have correct frontmatter
- All 6 sections are present in each pattern
- DSPy 3.x syntax compliance (no `prefix=`, uses `dspy.InputField`, etc.)
- No broken internal links

---

## 📤 Transfer to Air-Gapped Environment

### Option 1: USB drive

```bash
# On internet-connected machine
cp -r ~/dspy-knowledge-offline /Volumes/USB/dspy-knowledge-offline

# On air-gapped machine
cp -r /Volumes/USB/dspy-knowledge-offline ~/Documents/
```

### Option 2: tar.gz archive

```bash
# Create archive
cd ~ && tar czf dspy-knowledge-offline.tar.gz dspy-knowledge-offline

# Transfer via secure medium, then extract
tar xzf dspy-knowledge-offline.tar.gz
```

### Option 3: Git bundle

```bash
# Create bundle
cd ~/dspy-knowledge-offline && git bundle create dspy-kb.bundle main

# Extract on air-gapped machine
git bundle unbundle dspy-kb.bundle
```

---

## 📘 File Format Notes

- **All files are UTF-8 Markdown** — readable in any text editor (VS Code, Vim, Nano, Notepad)
- **No binary dependencies** — pure text, works on any OS
- **Python scripts require Python 3.7+** — standard library only, no pip install needed
- **INDEX.json** — machine-readable for custom tool integration

---

## ⚙️ Updating the Offline Package

When you regain internet access:

```bash
# Pull latest from GitHub
cd ~/Wiki/pages/dspy-framework && git pull origin main

# Regenerate offline package
# (Re-run the export script that created this package)
```

---

## 📋 License

MIT — Same as the upstream [DSPy](https://github.com/stanfordnlp/dspy) project.

---

**Packaged:** 2026-05-14  
**Patterns:** 22 / 22 (100% complete)  
**DSPy Version:** 3.x
