#!/usr/bin/env python3
"""
Offline validation tool for DSPy Knowledge Base.
Checks file integrity, frontmatter, and DSPy 3.x syntax compliance.

Usage:
    python validate.py              # Full validation
    python validate.py --quick      # Quick check (files exist only)
    python validate.py --pattern P01  # Validate specific pattern
"""

import json
import sys
import re
import argparse
from pathlib import Path


def load_index():
    script_dir = Path(__file__).parent.resolve()
    index_path = script_dir.parent / "INDEX.json"
    if not index_path.exists():
        print("❌ INDEX.json not found")
        sys.exit(1)
    with open(index_path, "r", encoding="utf-8") as f:
        return json.load(f)


def check_frontmatter(content, filename):
    """Verify YAML frontmatter exists and has required fields."""
    errors = []
    if not content.startswith("---"):
        errors.append(f"Missing frontmatter")
        return errors

    fm_end = content.find("---", 3)
    if fm_end < 0:
        errors.append(f"Unclosed frontmatter")
        return errors

    fm = content[3:fm_end].strip()
    required = ["pattern_id", "difficulty"]
    for field in required:
        if f"{field}:" not in fm:
            errors.append(f"Missing '{field}' in frontmatter")

    return errors


def check_sections(content, filename):
    """Verify all 6 sections exist."""
    errors = []
    required_sections = [
        "核心思想",
        "类图与数据流",
        "最小可运行代码",
        "反模式",
        "组合",
        "进阶变体"
    ]

    for section in required_sections:
        if section not in content:
            errors.append(f"Missing section: {section}")

    return errors


def check_dspy_syntax(content, filename):
    """Check for DSPy 3.x compliance."""
    errors = []
    warnings = []

    # Must have dspy.InputField and dspy.OutputField (not prefix=)
    if "dspy.InputField" not in content and "InputField" not in content:
        warnings.append("No dspy.InputField found")
    if "dspy.OutputField" not in content and "OutputField" not in content:
        warnings.append("No dspy.OutputField found")

    # Should NOT use deprecated prefix= in new patterns
    if "prefix=" in content and "anti-pattern" not in content.lower():
        warnings.append("Uses deprecated 'prefix=' parameter")

    # Should use dspy.LM or dspy.configure
    if "dspy.LM(" not in content and "dspy.configure" not in content:
        warnings.append("No dspy.LM() or dspy.configure() found")

    # Should have type annotations (simple heuristic)
    if "-> " not in content and "def forward" in content:
        warnings.append("forward() may be missing type annotations")

    return errors, warnings


def validate_pattern(index, pattern_id=None, quick=False):
    """Validate one or all patterns."""
    script_dir = Path(__file__).parent.resolve()
    patterns_dir = script_dir.parent / "patterns"

    patterns = index.get("patterns", [])
    if pattern_id:
        patterns = [p for p in patterns if p.get("id", "").upper() == pattern_id.upper()]
        if not patterns:
            print(f"❌ Pattern '{pattern_id}' not found in index")
            sys.exit(1)

    total = len(patterns)
    passed = 0
    failed = 0

    print(f"\n═" * 70)
    print(f"Validating {total} pattern(s)...")
    print("═" * 70)

    for p in patterns:
        pid = p.get("id", "UNKNOWN")
        fname = p.get("file", "").replace("patterns/", "")
        fpath = patterns_dir / fname

        print(f"\n🔍 {pid}: {fname}")

        if not fpath.exists():
            print(f"   ❌ FILE MISSING: {fpath}")
            failed += 1
            continue

        if quick:
            print(f"   ✅ File exists")
            passed += 1
            continue

        content = fpath.read_text(encoding="utf-8")
        all_errors = []
        all_warnings = []

        # Check frontmatter
        fm_errors = check_frontmatter(content, fname)
        all_errors.extend(fm_errors)

        # Check sections
        sec_errors = check_sections(content, fname)
        all_errors.extend(sec_errors)

        # Check DSPy syntax
        syntax_errors, syntax_warnings = check_dspy_syntax(content, fname)
        all_errors.extend(syntax_errors)
        all_warnings.extend(syntax_warnings)

        if all_errors:
            for e in all_errors:
                print(f"   ❌ {e}")
            failed += 1
        else:
            print(f"   ✅ Structure OK")
            passed += 1

        if all_warnings:
            for w in all_warnings:
                print(f"   ⚠️  {w}")

    print(f"\n{'═' * 70}")
    print(f"Results: {passed} passed, {failed} failed out of {total}")
    print("═" * 70)

    return failed == 0


def validate_core_docs(index):
    """Check core documentation files exist."""
    script_dir = Path(__file__).parent.resolve()
    core_dir = script_dir.parent / "core"

    print(f"\n📖 Core Documents:")
    for doc in index.get("core_docs", []):
        fpath = script_dir.parent / doc.get("file", "")
        if fpath.exists():
            print(f"   ✅ {doc.get('title', '')}")
        else:
            print(f"   ❌ MISSING: {fpath}")

    return True


def main():
    parser = argparse.ArgumentParser(description="Validate DSPy Knowledge Base offline package")
    parser.add_argument("--quick", action="store_true", help="Quick check (files exist only)")
    parser.add_argument("--pattern", help="Validate specific pattern ID (e.g., P01)")
    args = parser.parse_args()

    index = load_index()

    print("🔧 DSPy Knowledge Base — Offline Validation")
    print(f"Package: {index['meta']['name']}")
    print(f"Patterns: {index['meta']['total_patterns']}")

    ok = validate_pattern(index, args.pattern, args.quick)
    validate_core_docs(index)

    if ok:
        print("\n🎉 All checks passed!")
        sys.exit(0)
    else:
        print("\n⚠️  Some checks failed. See details above.")
        sys.exit(1)


if __name__ == "__main__":
    main()
