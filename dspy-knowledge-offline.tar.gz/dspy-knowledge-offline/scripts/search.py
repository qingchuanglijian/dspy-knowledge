#!/usr/bin/env python3
"""
Offline search tool for DSPy Knowledge Base.
No internet required. Python 3.7+ standard library only.

Usage:
    python search.py "keyword"              # Search patterns
    python search.py --difficulty advanced  # Filter by difficulty
    python search.py --list                 # List all patterns
    python search.py --file                 # Output file paths only
    python search.py "RAG" --file           # Find RAG pattern file path
"""

import json
import sys
import os
import argparse
import re
from pathlib import Path


def load_index():
    """Load INDEX.json from the package root."""
    script_dir = Path(__file__).parent.resolve()
    index_path = script_dir.parent / "INDEX.json"
    if not index_path.exists():
        print(f"Error: INDEX.json not found at {index_path}", file=sys.stderr)
        print("Run this script from inside the dspy-knowledge-offline directory.", file=sys.stderr)
        sys.exit(1)
    with open(index_path, "r", encoding="utf-8") as f:
        return json.load(f)


def search_patterns(index, query, difficulty=None):
    """Search patterns by keyword and optional difficulty filter."""
    results = []
    query_lower = query.lower()

    for p in index.get("patterns", []):
        # Difficulty filter
        if difficulty and p.get("difficulty", "").lower() != difficulty.lower():
            continue

        # Search in id, title, summary, keywords
        searchable = " ".join([
            p.get("id", ""),
            p.get("title", ""),
            p.get("summary", ""),
            " ".join(p.get("keywords", []))
        ]).lower()

        if query_lower in searchable:
            results.append(p)

    return results


def list_all(index):
    """List all patterns as a formatted table."""
    patterns = index.get("patterns", [])
    if not patterns:
        print("No patterns found in index.")
        return

    print(f"\n{'ID':<6} {'Difficulty':<12} {'Title':<30} {'File'}")
    print("-" * 80)
    for p in sorted(patterns, key=lambda x: x.get("id", "")):
        print(f"{p.get('id', ''):<6} {p.get('difficulty', ''):<12} {p.get('title', ''):<30} {p.get('file', '')}")
    print(f"\nTotal: {len(patterns)} patterns")


def print_results(results, file_only=False):
    """Print search results."""
    if not results:
        print("No matching patterns found.")
        return

    if file_only:
        for r in results:
            print(r.get("file", ""))
        return

    print(f"\nFound {len(results)} matching pattern(s):\n")
    for r in results:
        print(f"  📌 {r.get('id', '')}: {r.get('title', '')}")
        print(f"     Difficulty: {r.get('difficulty', 'unknown')}")
        print(f"     File: {r.get('file', '')}")
        if r.get("api_modules"):
            print(f"     API: {r['api_modules']}")
        if r.get("keywords"):
            print(f"     Keywords: {', '.join(r['keywords'][:6])}")
        if r.get("summary"):
            summary = r["summary"].replace("\n", " ")[:120]
            print(f"     Summary: {summary}...")
        print()


def main():
    parser = argparse.ArgumentParser(
        description="Search DSPy Knowledge Base (offline)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s "RAG"                    Search for RAG patterns
  %(prog)s --difficulty advanced    Show all advanced patterns
  %(prog)s --list                   List all patterns
  %(prog)s "router" --file          Get file path for router pattern
        """
    )
    parser.add_argument("query", nargs="?", default="", help="Search keyword")
    parser.add_argument("--difficulty", choices=["foundation", "beginner", "intermediate", "advanced", "expert"], help="Filter by difficulty")
    parser.add_argument("--list", action="store_true", help="List all patterns")
    parser.add_argument("--file", action="store_true", help="Output file paths only")

    args = parser.parse_args()
    index = load_index()

    if args.list:
        list_all(index)
        return

    if not args.query and not args.difficulty:
        parser.print_help()
        return

    # If only difficulty filter, search with empty query (matches all)
    query = args.query if args.query else ""
    results = search_patterns(index, query, args.difficulty)
    print_results(results, args.file)


if __name__ == "__main__":
    main()
