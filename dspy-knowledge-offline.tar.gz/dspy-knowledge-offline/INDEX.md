# DSPy Knowledge Base — Offline Index

> 🔑 **Self-contained, no internet required.**  
> 22 design patterns + 4 core docs + IDE configs for DSPy 3.x

---

## 📚 Pattern Quick Reference (22 total)

| ID | Pattern | Difficulty | File | Keywords |
|---|---|---|---|---|
| P01-Predict | Predict | foundation | `patterns/predict.md` | InputField, OutputField, anti-pattern, composition, dspy.LM |
| P02-ChainOfThought | Chain Of Thought | foundation | `patterns/chain-of-thought.md` | InputField, OutputField, anti-pattern, composition, dspy.ChainOfThought |
| P03-ReAct | React Agent | intermediate | `patterns/react-agent.md` | InputField, OutputField, anti-pattern, async, composition |
| P04-RAG | Rag | beginner | `patterns/rag.md` | BootstrapFewShot, InputField, OutputField, anti-pattern, composition |
| P05-MultiHopRAG | Multi Hop | advanced | `patterns/multi-hop.md` | InputField, OutputField, anti-pattern, composition, dspy.ChainOfThought |
| P06-ProgramOfThought | Program Of Thought | intermediate | `patterns/program-of-thought.md` | InputField, OutputField, anti-pattern, composition, dspy.ChainOfThought |
| P07-CustomModule | Custom Module | foundation-intermediate | `patterns/custom-module.md` | InputField, OutputField, anti-pattern, composition, dspy.ChainOfThought |
| P08-BestOfN | Best Of N | intermediate | `patterns/best-of-n.md` | InputField, OutputField, anti-pattern, composition, dspy.LM |
| P09-Refine | Refine | intermediate | `patterns/refine.md` | InputField, OutputField, anti-pattern, composition, dspy.LM |
| P10-Parallel | Parallel | intermediate | `patterns/parallel.md` | InputField, OutputField, anti-pattern, async, composition |
| P11-MultiChainComparison | Multi Chain Comparison | advanced | `patterns/multi-chain-comparison.md` | InputField, OutputField, anti-pattern, composition, dspy.ChainOfThought |
| P12-Router | Router | intermediate | `patterns/router.md` | BootstrapFewShot, InputField, OutputField, anti-pattern, composition |
| P13-ConversationHistory | Conversation History | intermediate | `patterns/conversation-history.md` | InputField, OutputField, anti-pattern, composition, dspy.LM |
| P14-BootstrapFewShot | Bootstrap Few Shot | intermediate | `patterns/bootstrap-few-shot.md` | BootstrapFewShot, InputField, OutputField, anti-pattern, composition |
| P15-MIPROv2 | Mipro V2 | advanced | `patterns/mipro-v2.md` | BootstrapFewShot, InputField, MIPROv2, OutputField, anti-pattern |
| P16-GEPA | Gepa | advanced | `patterns/gepa.md` | BootstrapFewShot, InputField, MIPROv2, OutputField, anti-pattern |
| P17-RLOptimization | Rl Optimization | expert | `patterns/rl-optimization.md` | BootstrapFewShot, InputField, MIPROv2, OutputField, anti-pattern |
| P18-Ensemble | Ensemble | intermediate | `patterns/ensemble.md` | BootstrapFewShot, InputField, OutputField, anti-pattern, composition |
| P19-MCPIntegration | Mcp Integration | intermediate | `patterns/mcp-integration.md` | InputField, OutputField, anti-pattern, composition, dspy.ChainOfThought |
| P20-Streaming | Streaming | intermediate | `patterns/streaming.md` | InputField, OutputField, anti-pattern, composition, dspy.ChainOfThought |
| P21-Async | Async | intermediate | `patterns/async.md` | InputField, OutputField, anti-pattern, async, composition |
| P22-SavingLoading | Saving Loading | beginner | `patterns/saving-loading.md` | BootstrapFewShot, InputField, MIPROv2, OutputField, anti-pattern |

---

## 📖 Core Documentation

| Document | File | Purpose |
|---|---|---|
| Api Cheatsheet 3X | `core/api-cheatsheet-3x.md` | DSPy 3.x API Cheatsheet

**Purpose:** Quick syntax reference during implementati... |
| Common Pitfalls | `core/common-pitfalls.md` | DSPy Common Pitfalls

**Purpose:** Traps discovered through real project usage. ... |
| Core Concepts | `core/core-concepts.md` | DSPy Core Concepts (3.x)

**Purpose:** Deep understanding of DSPy's 5 pillars — ... |
| Migration 2X To 3X | `core/migration-2x-to-3x.md` | DSPy 2.x → 3.x Migration Guide

**Purpose:** Checklist for upgrading existing DS... |

---

## 🛠️ IDE Configurations (Exports)

| File | Target IDE | Usage |
|---|---|---|
| `exports/.cursorrules-dspy` | Cursor IDE | Copy to project root as `.cursorrules` |
| `exports/CLAUDE.md-dspy` | Claude Code / Projects | Copy to project root as `CLAUDE.md` |
| `exports/README.md` | Generic | See file header |
| `exports/system-prompt-dspy.md` | Any LLM API | Paste into system prompt |

---

## 🔍 How to Search (Offline)

### Method 1: Use the search script
```bash
cd dspy-knowledge-offline
python scripts/search.py "ChainOfThought"     # Search by keyword
python scripts/search.py --difficulty advanced  # Filter by difficulty
python scripts/search.py --list               # List all patterns
```

### Method 2: Use VS Code / Cursor
1. Open `dspy-knowledge-offline/` as workspace
2. Press `Ctrl+Shift+F` (or `Cmd+Shift+F`) for global search
3. All patterns are plain text Markdown — instant full-text search

### Method 3: Read the catalog
Open `patterns/pattern-catalog.md` for the decision tree and composition matrix.

---

## 📁 Directory Structure

```
dspy-knowledge-offline/
├── INDEX.json              # Machine-readable index
├── INDEX.md                # This file — human-readable index
├── README.md               # Original project README
├── README-OFFLINE.md       # Offline usage guide
├── patterns/               # 22 pattern docs + catalog
│   ├── pattern-catalog.md
│   ├── predict.md
│   ├── chain-of-thought.md
│   └── ... (20 more)
├── core/                   # 4 core concept docs
│   ├── core-concepts.md
│   ├── api-cheatsheet-3x.md
│   ├── migration-2x-to-3x.md
│   └── common-pitfalls.md
├── exports/                # IDE configuration files
│   ├── .cursorrules-dspy
│   ├── CLAUDE.md-dspy
│   └── system-prompt-dspy.md
└── scripts/                # Offline tools
    ├── search.py
    └── validate.py
```

---

**Generated:** 2026-05-14  
**DSPy Version:** 3.x  
**Total Patterns:** 22 / 22 (100%)
